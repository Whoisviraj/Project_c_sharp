﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace Car_Racing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Class1.src = textBox1.Text;
            textBox4.PasswordChar = '*';
            textBox2.PasswordChar = '*';
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel2.Visible = panel2.Enabled = true;
            groupBox2.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel2.Visible = panel2.Enabled = false;
            label5.Visible = false;
        }

      

        private void login_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                string sql = "select * from detail where usenm='" + textBox1.Text + "' AND pass='" + textBox2.Text + "'";
                Class1.src = textBox1.Text;
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                int b = da.Fill(dt);
                if (b == 1)
                {
                    CAR c = new CAR();
                    c.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please enter the correct detail");
                    clear();
                }
       
            }
            else
            {
                MessageBox.Show("Enter detail");
            }
        }

        private void btnreg_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "" && textBox4.Text != "")
            {
                string sql1 = "insert into detail (usenm,pass) values('" + textBox3.Text + "','" + textBox4.Text + "')";
                SqlDataAdapter da1 = new SqlDataAdapter(sql1, Class1.cn);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                MessageBox.Show("Record Inserted");
            }
            else
            {
                MessageBox.Show("Please enter the values...");
                clear();
            }
        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string query = "select * from detail where usenm like '" + textBox3.Text + "' ";
            SqlDataAdapter da3 = new SqlDataAdapter(query,Class1.cn);
            DataTable dt3 = new DataTable();
            da3.Fill(dt3);
            if (dt3.Rows.Count > 0)
            {
                label5.Visible = true;
                btnreg.Visible = false;
            }
            else
            {
                label5.Visible = false;
                btnreg.Visible = true;
            }
        }
    }
}
