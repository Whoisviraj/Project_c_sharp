﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Car_Racing
{
    public partial class CAR : Form
    {
        //global variables
        int carSpeed = 5;
        int roadSpeed = 5;
        bool carLeft;
        bool carRight;
        int trafficSpeed = 5;
        int Score = 0;
        Random rnd = new Random();

        public CAR()
        {
            InitializeComponent();
            Reset();
        }

        private void CAR_Load(object sender, EventArgs e)
        {
            timer1.Dispose();
        }
        private void Reset()
        {
            trophy.Visible = false;                            // hide image
            button1.Enabled = false;                           // disable the button
            explosion.Visible = false;                         // hide the explosion 
            trafficSpeed = 5;                                  // set the traffic restart 
            roadSpeed = 5;                                     // set the road speed restart 
            Score = 0;                                          // reset score to 0 

            player.Left = 161;     // reset player left
            player.Top = 286;      // reset player top
            carLeft = false;    // reset the moving left to false
            carRight = false;   // reset the moving right to false

            // reset the AI to default position 
            AI1.Left = 66; 
            AI1.Top = -120; 
            AI2.Left = 294;
            AI2.Top = -185;
 
            //reset the road position
            Road2.Left = -3;
            Road2.Top = -222;
            Road1.Left = -2;
            Road1.Top = -638; 
            
            timer1.Start();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            Score++; // increase the score as we move

            distance.Text = "" + Score; // show the score on the distance label

            Road1.Top += roadSpeed; // move the track 1 down with the += 
            Road2.Top += roadSpeed; // move the track 2 down with the += 

            //  Track  Restart Like Animation 
            if (Road1.Top > 630)
            {
                Road1.Top = -630;
            }
            if (Road2.Top > 630)
            {
                Road2.Top = -630;
            }
            // end of track animation.
        }
        }
       

           
        }
    
